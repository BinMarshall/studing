package com.example.springbootcloudprovider.server;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 功能描述：
 * 作者姓名：Hao Bin - MARSHALL
 * 创建时间：2018/7/2 14:45
 */
@RestController
@RequestMapping("/server")
public class TestServer {

    @RequestMapping("/test")
    public String test(String params){
        System.out.println("I am TestServer - "+params);
        return params;
    }
}
