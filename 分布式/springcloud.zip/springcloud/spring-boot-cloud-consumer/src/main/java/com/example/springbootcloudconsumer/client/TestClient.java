package com.example.springbootcloudconsumer.client;

import com.example.springbootcloudconsumer.inter.ClientProxy;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;

/**
 * 功能描述：
 * 作者姓名：Hao Bin - MARSHALL
 * 创建时间：2018/7/2 14:47
 */
@Controller
@RequestMapping("/client")
public class TestClient {
    @Resource
    ClientProxy proxy;

    @RequestMapping("/test")
    @ResponseBody
    public String test(){
        System.out.println("I am TestClient");
        String result = proxy.test("I Am Fin");
        System.out.println(result);
        return result;
    }
}
