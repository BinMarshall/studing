package com.example.springbootcloudconsumer.inter;

/**
 * 功能描述：
 * 作者姓名：Hao Bin - MARSHALL
 * 创建时间：2018/7/2 15:00
 */
public class DefaultHystrixImpl implements ClientProxy {
    @Override
    public String test(String params) {
        return null;
    }
}
