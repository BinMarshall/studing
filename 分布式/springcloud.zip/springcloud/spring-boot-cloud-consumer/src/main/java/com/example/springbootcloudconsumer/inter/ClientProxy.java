package com.example.springbootcloudconsumer.inter;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 功能描述：
 * 作者姓名：Hao Bin - MARSHALL
 * 创建时间：2018/7/2 14:59
 */
@FeignClient(value = "${remote.server}", fallback = DefaultHystrixImpl.class)
public interface ClientProxy {
    @RequestMapping("/server/test")
    public String test(@RequestParam("params") String params);
}